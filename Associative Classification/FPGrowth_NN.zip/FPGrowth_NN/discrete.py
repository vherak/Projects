import pandas as pd
from sklearn.preprocessing import KBinsDiscretizer
from mlxtend.preprocessing import minmax_scaling
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import minmax_scale

import numpy as np

# Discretization
def discretize_data():
    data = pd.read_csv("breast-cancer-wisconsin.data",header=None)

    numeric_data = data._get_numeric_data()
    numerical_columns = list(data._get_numeric_data().columns)
    discretizer = KBinsDiscretizer(n_bins=15,encode='ordinal',strategy='uniform')
    numeric_data = discretizer.fit_transform(numeric_data)

    for i in range(len(numerical_columns)):
        data.iloc[:,numerical_columns[i]] = numeric_data[:,i]

    print(data)




# Min Max Scaling
def min_max():
    data = pd.read_csv("breast-cancer-wisconsin.data", header=None)
    print('orginal\n',data)
    numeric_data = data._get_numeric_data()
    numerical_columns = list(data._get_numeric_data().columns)
    numeric_data = minmax_scale(numeric_data)

    # data.to_csv('test',header=None,index=False)
    # numeric_data.to_csv('test2',header=None,index=False)
    numeric_data = pd.DataFrame(numeric_data)
    print(numeric_data)

    for i in range(len(numerical_columns)):
        data.iloc[:, numerical_columns[i]] = numeric_data.iloc[:,i]

    data.to_csv('test.csv',index=False,header=None)




min_max()